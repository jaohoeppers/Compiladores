package scanner;

import java.io.BufferedReader;
//import edu.princeton.cs.algs4.Stdin;
//import edu.princeton.cs.algs4.Stdout;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.logging.Level;
import java.util.logging.Logger;

import java_cup.runtime.ComplexSymbolFactory;
import java_cup.runtime.ScannerBuffer;
import java_cup.runtime.Symbol;

public class ListTokens {

	@SuppressWarnings({ "null", "unused" })
	public static void main(String[] args) throws Exception {

		String filePath = "C:\\teste\\testeana.txt";

		try {
			
			ComplexSymbolFactory csf = new ComplexSymbolFactory();
//			
//			Lexer lexer = new Lexer(new FileReader(filePath),csf);
//			
//			System.out.println(lexer.nextSymbol());
//			
//			parser p = new parser(lexer,csf);
			
//			Object result = p.parse().value;
			
			
			Lexer lex = new Lexer(new FileReader(filePath), new ComplexSymbolFactory());
//			System.out.println(lex.nextSymbol());
//			parser par = new parser(lex,csf);
//			Object result = par.parse();

//			System.out.println(result);

			Symbol symbol;

			while((symbol = lex.nextSymbol()) !=null) {
				if (symbol.sym==0) {
					break;
				}
				System.out.print(symbol.sym);
				System.out.println();
			}

		} catch (IOException ex) {
			Logger.getLogger(ListTokens.class.getName()).log(Level.SEVERE, null, ex);
		}

	}

}
